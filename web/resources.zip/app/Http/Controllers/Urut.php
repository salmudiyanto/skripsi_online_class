<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Urut extends Controller
{
    //
}
