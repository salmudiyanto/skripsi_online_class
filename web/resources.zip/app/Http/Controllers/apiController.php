<?php

namespace App\Http\Controllers;

use App\Models\jadwal_kelas;
use App\Models\jadwal_ujian;
use App\Models\Kuis;
use App\Models\Mapel;
use App\Models\Materi;
use App\Models\Tugas;
use App\Models\Ujian;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use File;
use Illuminate\Support\Facades\DB;


class apiController extends Controller
{
    public function jadwalkelas($id){
        $datamapel = jadwal_kelas::where('users.id', $id)
        ->select('jadwal_kelas.*', 'mapels.id as idmapel', 'mapels.nama_mapel as namamapel', 'siswas.id_user as idusersiswa', 'users.id as iduser', 'users.name as siswa', 'kelas.namakelas as namakelas', 'kelas.id as idkelas'
        )->leftJoin('mapels', function($join){
            $join->on('jadwal_kelas.mapel', '=', 'mapels.id');
        })->leftJoin('kelas', function($join){
            $join->on('jadwal_kelas.kelas', '=', 'kelas.id');
        })->leftJoin('siswas', function($join){
            $join->on('kelas.id', '=', 'siswas.kelas');
        })->leftJoin('users', function($join){
            $join->on('users.id', '=', 'siswas.id_user');
        })->get();


        return response()->json($datamapel);
    }

    public function materi($id){
        $datamapel = jadwal_kelas::where('users.id', $id)
        ->select('jadwal_kelas.*', 'mapels.id as idmapel', 'mapels.nama_mapel as namamapel', 'siswas.id_user as idusersiswa', 'users.id as iduser', 'users.name as siswa', 'kelas.namakelas as namakelas', 'kelas.id as idkelas'
        )->leftJoin('mapels', function($join){
            $join->on('jadwal_kelas.mapel', '=', 'mapels.id');
        })->leftJoin('kelas', function($join){
            $join->on('jadwal_kelas.kelas', '=', 'kelas.id');
        })->leftJoin('siswas', function($join){
            $join->on('kelas.id', '=', 'siswas.kelas');
        })->leftJoin('users', function($join){
            $join->on('users.id', '=', 'siswas.id_user');
        })->get();

        return response()->json($datamapel);

    }

    public function kuis($id){
        $datakuis = Kuis::where('users.id', $id)->where('kuis.stat', 'B')->select('kuis.*', 'siswas.*', 'users.name as namasiswa', 'mapels.*'
        )->leftJoin('siswas', function($join){
            $join->on('siswas.id', '=', 'kuis.siswa');
        })->leftJoin('users', function($join){
            $join->on('siswas.id_user', '=', 'users.id');
        })->leftJoin('kelas', function($join){
            $join->on('siswas.kelas', '=', 'kelas.id');
        })->leftJoin('jadwal_kelas', function($join){
            $join->on('jadwal_kelas.kelas', '=', 'kelas.id');
        })->leftJoin('mapels', function($join){
            $join->on('siswas.kelas', '=', 'kelas.id');
        })->get();

        
        return response()->json($datakuis);


    }
    
    public function tugaslist($siswa, $mapel){
        $datatugas = Tugas::where('users.id', $siswa)->where('tugas.stat', 'B')->where('tugas.mapel', $mapel)->select('tugas.*', 'tugas.id as idTugas', 'siswas.*', 'users.name as namasiswa', 'mapels.*')->leftJoin('siswas', function($join){
            $join->on('siswas.id', '=', 'tugas.siswa');
        })->leftJoin('users', function($join){
            $join->on('siswas.id_user', '=', 'users.id');
        })->leftJoin('mapels', function($join){
                $join->on('tugas.mapel', '=', 'mapels.id');
        })->get();


        //  $datatugas = Tugas::where('user.id', $siswa)->where('tugas.stat', 'B')->where('tugas.mapel', $mapel)->select('tugas.*', 'tugas.id as idTugas', 'siswas.*', 'users.name as namasiswa', 'mapels.*'
        // )->leftJoin('siswas', function($join){
        //     $join->on('siswas.id', '=', 'tugas.siswa');
        // })->leftJoin('users', function($join){
        //     $join->on('siswas.id_user', '=', 'users.id');
        // })->leftJoin('kelas', function($join){
        //     $join->on('siswas.kelas', '=', 'kelas.id');
        // })->leftJoin('jadwal_kelas', function($join){
        //     $join->on('jadwal_kelas.kelas', '=', 'kelas.id');
        // })->leftJoin('mapels', function($join){
        //     $join->on('siswas.kelas', '=', 'kelas.id');
        // })->get();
        
        return response()->json($datatugas);

    }

    public function loginsiswa(Request $request){
        $email = $request->email;
        $password = $request->password;
        $cek = User::where('email', $email)->first();
        if($cek){
            if(Hash::check($password, $cek->password)){
                return response([
                    'status' => 'OK',
                    'message' => 'Berhasil Login',
                    'id_siswa' => $cek->id,
                    'nama_siswa' => $cek->name,
                ]);
            }else{
                return response([
                    'status' => 'NO',
                    'message' => 'Password Tidak Cocok'
                ]);
            }
        }else{
            return response([
                'status' => 'NO',
                'message' => 'Username Tidak di Temukan'
            ]);
        }

    }

    public function tugas($id){
        $datatugas = Tugas::where('users.id', $id)->where('tugas.stat', 'B')->select('tugas.*', 'siswas.*', 'users.name as namasiswa', 'mapels.*'
        )->leftJoin('siswas', function($join){
            $join->on('siswas.id', '=', 'tugas.siswa');
        })->leftJoin('users', function($join){
            $join->on('siswas.id_user', '=', 'users.id');
        })->leftJoin('kelas', function($join){
            $join->on('siswas.kelas', '=', 'kelas.id');
        })->leftJoin('jadwal_kelas', function($join){
            $join->on('jadwal_kelas.kelas', '=', 'kelas.id');
        })->leftJoin('mapels', function($join){
            $join->on('siswas.kelas', '=', 'kelas.id');
        })->get();
        return response()->json($datatugas);

    }
    
    public function tampilsoal($id){
        $datatugas = Tugas::where('id', $id)->first();
        return view('soal', ['soal' => $datatugas->deskripsi]);
    }

    public function tampilsoalkuis($id){
        $datatugas = Kuis::where('id', $id)->first();
        return view('soal', ['soal' => $datatugas->deskripsi]);
    }

    public function soal($id){
        $dataujian = jadwal_ujian::select('soals.*')->where('qr', $id)->
        leftJoin('soals', function($join){
            $join->on('soals.kelompoksoal', '=', 'jadwal_ujians.id');
        })
        ->get();
        return response()->json($dataujian);

    }

    public function kirimtugastext(Request $req){
        Tugas::where('id', $req->idTugas)->update([
            'stat' => 'B',
            'jawab' => $req->jawab
        ]);
        return response([
            'status' => 'Ok',
            'message' => 'Berhasil Simpan'
        ], 200);
    }

    public function kirimtugasfile(Request $req){
        $jenis = explode(".", $req->namafile);
        $tipe = $jenis[count($jenis)-1];
        $image = $req->file;  // your base64 encoded
        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);
        $imageName = rand(1000, 9999).'.'.$tipe;

        File::put(public_path('filetugas'). '/' . $imageName, base64_decode($image));
        Tugas::where('id', $req->idTugas)->update([
            'stat' => 'B',
            'file' => $imageName
        ]);
        return response([
            'status' => 'Ok',
            'message' => 'Berhasil Simpan'
        ], 200);
    }


    public function submitujian($id, $benar, $siswa){
        // try{
            $dataujian = jadwal_ujian::where('id', $id)->first();
            $ujian = new Ujian;
            $ujian->mapel = $dataujian->mapel;
            $ujian->urut = $dataujian->urut;
            $ujian->id_soal = $dataujian->id;
            $ujian->siswa = $siswa;
            $ujian->nilai = $benar;
            $ujian->deskripsi = $dataujian->qr;
            $ujian->mulai = date('H:i:s');
            $ujian->selesai = date('H:i:s');
            $ujian->stat = 'S';
            $ujian->save();
            return response([
                'status' => 'Ok',
                'message' => 'Berhasil Simpan'
            ], 200);
        // }catch(Exception $e){
        //     dd($e);
        // }

    }

    public function ujianqr($id){
        $datamapel = jadwal_ujian::where('qr', $id)
        ->select('jadwal_ujians.*', 'mapels.id as idmapel', 'mapels.nama_mapel as namamapel'
        )->leftJoin('mapels', function($join){
            $join->on('jadwal_ujians.mapel', '=', 'mapels.id');
        })->get();

        return response()->json($datamapel);

    }

    public function idujian($id){
        $datamapel = jadwal_ujian::where('qr', $id)->first();

        return response()->json($datamapel);

    }

    public function materimapel($id){
        $datamapel = Materi::where('mapels.id', $id)->select('materis.id as idmateri', 'materis.judul as judul', 'materis.mapel as mapel', 'materis.urut as urut', 'materis.tingkat as tingkat', 'materis.tahunajaran as tahunajaran', 'materis.deskripsi as deskripsi', 'materis.file as file', 'mapels.id as id', 'mapels.guru as guru', 'mapels.nama_mapel as nama_mapel'
        )->leftJoin('mapels', function($join){
            $join->on('materis.mapel', '=', 'mapels.id');
        })->get();

        return response()->json($datamapel);

    }
    
    public function dashboard($id){
        $datamateri = Materi::where('users.id', $id)->select('materis.judul')->leftJoin('mapels', function($join){
                $join->on('materis.mapel', '=', 'mapels.id');
            })->leftJoin('jadwal_kelas', function($join){
                $join->on('jadwal_kelas.mapel', '=', 'mapels.id');
            })->leftJoin('kelas', function($join){
                $join->on('jadwal_kelas.kelas', '=', 'kelas.id');
            })->leftJoin('siswas', function($join){
                $join->on('kelas.id', '=', 'siswas.kelas');
            })->leftJoin('users', function($join){
                $join->on('users.id', '=', 'siswas.id_user');
            })->distinct()->get();
            
        $datamapel = Mapel::where('users.id', $id)->select('mapels.nama_mapel')->leftJoin('jadwal_kelas', function($join){
                $join->on('jadwal_kelas.mapel', '=', 'mapels.id');
            })->leftJoin('kelas', function($join){
                $join->on('jadwal_kelas.kelas', '=', 'kelas.id');
            })->leftJoin('siswas', function($join){
                $join->on('kelas.id', '=', 'siswas.kelas');
            })->leftJoin('users', function($join){
                $join->on('users.id', '=', 'siswas.id_user');
            })->distinct()->get();
            
        $datatugas = Tugas::where('users.id', $id)->select('tugas.*')->leftJoin('siswas', function($join){
                $join->on('tugas.siswa', '=', 'siswas.id');
            })->leftJoin('users', function($join){
                $join->on('users.id', '=', 'siswas.id_user');
            })->get();
        $dataujian = Ujian::where('users.id', $id)->select('ujians.*')->leftJoin('siswas', function($join){
                $join->on('ujians.siswa', '=', 'siswas.id');
            })->leftJoin('users', function($join){
                $join->on('users.id', '=', 'siswas.id_user');
            })->get();
                    
        $datakuis = Kuis::where('users.id', $id)->select('kuis.*')->leftJoin('siswas', function($join){
                $join->on('kuis.siswa', '=', 'siswas.id');
            })->leftJoin('users', function($join){
                $join->on('users.id', '=', 'siswas.id_user');
            })->get();

        return response([
                'materi' => count($datamateri),
                'tugas' => count($datatugas),
                'kuis' => count($datakuis),
                'ujian' => count($dataujian),
        ]);
    }
}
