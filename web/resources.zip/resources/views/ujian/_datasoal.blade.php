
@extends('guru')

@section('isiguru')
    
<div class="col-12">
  @foreach ($errors->all() as $error)
                                            
  <div class="alert alert-danger alert-mg-b">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
      <strong>Danger!</strong> {{ $error }}
  </div>
  
  @endforeach

  <div class="modal fade" id="modal-tambah">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Tambah Soal</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="{{ route('simpansoal') }}" method="post">
            {{ csrf_field() }}
            <input type="hidden" name="kelompoksoal" value="{{ $kelompoksoal }}">
            <div class="modal-body">
  
            <div class="container">

              <div id="pilgan" style="visibility: hidden">
                <div class="form-group">
                  <label for="soal">Soal</label>
                  <input type="text" name="soal" class="form-control" >
                </div>  
                <div class="form-group">
                  <label for="a">Pilihan A</label>
                  <input type="text" name="a" class="form-control" id="a">
                </div>          
                <div class="form-group">
                    <label for="b">Pilihan B</label>
                    <input type="text" name="b" class="form-control" id="b">
                </div>          
                <div class="form-group">
                    <label for="c">Pilihan C</label>
                    <input type="text" name="c" class="form-control" id="c">
                </div>          
                <div class="form-group">
                    <label for="d">Pilihan D</label>
                    <input type="text" name="d" class="form-control" id="d">
                </div>  
                <div class="form-group">
                  <label for="jawaban">Jawaban Benar</label>
                  <select name="jawaban" class="form-control" id="">
                      <option value="a">A</option>
                      <option value="b">B</option>
                      <option value="c">C</option>
                      <option value="d">D</option>
                  </select>
                </div>   
              </div>
              <div id="essay" style="visibility: hidden">
                <div class="form-group">
                  <label for="essay">Pilihan D</label>
                  <input type="text" name="essay" class="form-control" id="d">
              </div> 
              </div>       
            </div>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="reset" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan Ujian</button>
            </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

      
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Data Soal</h3>
        <div class="card-tools">
            <a href="#" class="btn btn-info" data-toggle="modal" data-target="#modal-tambah">Tambah</a>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>NO. </th>
              <th>Soal</th>
              <th>Pilihan A</th>
              <th>Pilihan B</th>
              <th>Pilihan C</th>
              <th>Pilihan D</th>
              <th>Jawaban</th>
              <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
              @php
                  $no=1;
              @endphp
  
              @foreach ($datasoal as $item)
                  
              <tr>
                <td>{{ $no++ }}</td>
                <td>{{ $item->soal }}</td>
                <td>{{ $item->a }}</td>
                <td>{{ $item->b }}</td>
                <td>{{ $item->c }}</td>
                <td>{{ $item->d }}</td>
                <td>{{ $item->jawaban_benar }}</td>
                <td>
                  <a href="{{ route('hapussoal', ['id' => $item->id, 'kelompoksoal' => $kelompoksoal]) }}" onclick="return confirm('Apakah anda yakin ingin menghapus ?')" class="btn btn-danger" >Hapus</a> | <a href="#" data-toggle="modal" data-target="#modaledit{{ $item->id }}" class="btn btn-warning">Edit</a>
                </td>
              </tr>


              <div class="modal fade" id="modaledit{{ $item->id }}">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title">Tambah Tugas</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="{{ route('simpaneditsoal') }}" method="post">
                        {{ csrf_field() }}
                        <input type="hidden" name="kelompoksoal" value="{{ $kelompoksoal }}">
                        <input type="hidden" name="id" value="{{ $item->id }}">
                        <div class="modal-body">
              
                        <div class="container">
                            <div class="form-group">
                                <label for="soal">Soal</label>
                                <input type="text" name="soal" value="{{ $item->soal }}" class="form-control" >
                            </div>  
                            <div class="form-group">
                              <label for="a">Pilihan A</label>
                              <input type="text" name="a" class="form-control" id="a" value="{{ $item->a }}">
                           </div>          
                           <div class="form-group">
                              <label for="b">Pilihan B</label>
                              <input type="text" name="b" class="form-control" id="b" value="{{ $item->b }}">
                           </div>          
                           <div class="form-group">
                              <label for="c">Pilihan C</label>
                              <input type="text" name="c" class="form-control" id="c" value="{{ $item->c }}">
                           </div>          
                           <div class="form-group">
                              <label for="d">Pilihan D</label>
                              <input type="text" name="d" class="form-control" id="d" value="{{ $item->d }}">
                           </div>  
                           <div class="form-group">
                            <label for="jawaban">Jawaban Benar</label>
                            <select name="jawaban" class="form-control" id="">
                                <option value="a" @if ($item->jawaban_benar == 'a')
                                    selected
                                @endif>A</option>
                                <option value="b" @if ($item->jawaban_benar == 'b')
                                    selected
                                @endif>B</option>
                                <option value="c" @if ($item->jawaban_benar == 'c')
                                    selected
                                @endif>C</option>
                                <option value="d" @if ($item->jawaban_benar == 'd')
                                    selected
                                @endif>D</option>
                            </select>
                         </div>          
                        </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="reset" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Simpan Ujian</button>
                        </div>
                    </form>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
      
              @endforeach
            
            </tbody>
            <tfoot>
              <tr>
                <th>NO. </th>
              <th>Soal</th>
              <th>Pilihan A</th>
              <th>Pilihan B</th>
              <th>Pilihan C</th>
              <th>Pilihan D</th>
              <th>Jawaban</th>
              <th>Aksi</th>
              </tr>
          </tfoot>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
  @endsection
