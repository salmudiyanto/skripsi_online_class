
@extends('guru')

@section('isiguru')
    
<div class="col-12">
  @foreach ($errors->all() as $error)
                                            
  <div class="alert alert-danger alert-mg-b">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
      <strong>Danger!</strong> {{ $error }}
  </div>
  
  @endforeach
      
      <div class="modal fade" id="modal-tambah">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Tambah Kuis</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <form action="{{ route('simpankuis') }}" method="post">
                  {{ csrf_field() }}
                  <div class="modal-body">

                  <div class="container">
                      <div class="form-group">
                          <label for="soal">Soal</label>
                          <textarea name="soal" id="soal" class="form-control" cols="30" rows="10"></textarea>
                      </div>  
                      <div class="form-group">
                        <label for="mulai">Mulai Kerjakan</label>
                        <input type="time" name="mulai" class="form-control" id="mulai">
                    </div>          
                    <div class="form-group">
                        <label for="deadline">Deadline</label>
                        <input type="time" name="deadline" class="form-control" id="deadline">
                    </div>                   
                  </div>
                  
                  <input type="hidden" name="kelas" value="{{ $kelas }}">
                  <input type="hidden" name="mapel" value="{{ $mapel }}">
                 

                  </div>
                  <div class="modal-footer justify-content-between">
                      <button type="reset" class="btn btn-default" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Save changes</button>
                  </div>
              </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>

    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Data Mata Pelajaran</h3>
        <div class="card-tools">
            <a href="#" class="btn btn-info" data-toggle="modal" data-target="#modal-tambah">Tambah</a>
          </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>NO. </th>
              <th>Nama Siswa</th>
              <th>Kuis Ke-</th>
              <th>Lihat Kuis</th>
              <th>Nilai</th>
            </tr>
            </thead>
            <tbody>
              @php
                  $no=1;
              @endphp
  
              @foreach ($datakuis as $item)
                  
              <tr>
                <td>{{ $no++ }}</td>
                <td>{{ $item->namasiswa }}</td>
                <td>{{ $item->urut }}</td>
                <td>
                  @if ($item->file != '-')
                  <form action="{{ route('filekuissiswa') }}" method="post">
                    {{ csrf_field() }}
                    <input type="hidden" name="siswa" value="{{ $item->siswaid }}">
                    <input type="hidden" name="idmapel" value="{{ $mapel }}">
                    <input type="hidden" name="urut" value="{{ $item->urut }}">
                    <button type="submit" class="btn btn-primary">Buka</button>
                  </form>
                  @endif </td>
                <td>

                  @if ($item->file != '-')
                  
                    <a href="#" data-toggle="modal" data-target="#modal-nilai{{ $item->id }}" value="Materi" class="btn btn-success">{{ $item->nilai }}</a>
                
                  @endif 

                  <div class="modal fade" id="modal-nilai{{ $item->id }}">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Tambah Tugas</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="{{ route('kuisnilai') }}" method="post">
                            {{ csrf_field() }}
                            <div class="modal-body">
          
                            <div class="container">     
                              <div class="form-group">
                                  <label for="nilai">Nilai</label>
                                  <input type="number" name="nilai" class="form-control" id="nilai">
                              </div>                   
                            </div>
                            
                            <input type="hidden" name="id" value="{{ $item->id }}">
          
                            </div>
                            <div class="modal-footer justify-content-between">
                                <button type="reset" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Beri Nilai</button>
                            </div>
                        </form>
                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
                  
                </td>
              </tr>
  
              @endforeach
            
            </tbody>
            <tfoot>
              <tr>
                <th>NO. </th>
                <th>Nama Siswa</th>
                <th>Tugas Ke-</th>
                <th>Lihat Tugas</th>
                <th>Nilai</th>
                </tr>
          </tfoot>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
  @endsection
