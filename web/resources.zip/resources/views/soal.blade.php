<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      @import url('https://fonts.googleapis.com/css?family=Montserrat:400,700&display=swap');

      
      body, p, h1, h2, h3, h4, h5, h6 {
        font-family: 'Montserrat', sans-serif;
      }
    </style>
  </head>
  <body>
    {!! $soal !!}
  </body>
</html>
